
public class Main_coche {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

				
			Coche miCoche = new Coche (3);
			
			System.out.println("Ayer miCoche tenia "+miCoche.getPuertas()+" puertas");
			
			miCoche.setPuertas(5);
			
			System.out.println("Hoy miCoche tiene "+miCoche.getPuertas()+" puertas");
			
			System.out.println(miCoche);
				
	}
			
}
	